dbPassword = '<< Your Mongo DB password >>';

module.exports = {
    mongoURI: dbPassword
};
