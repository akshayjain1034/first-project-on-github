dbPassword = 'mongodb+srv://Asher:evoting123@testcluster-yczvx.mongodb.net/test?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
